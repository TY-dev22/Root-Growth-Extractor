import tkinter as tk
from tkinter import filedialog
import main_GUI

# 保存先のフォルダパスと入力フォルダパスを保持する変数
save_folder = ""
input_folder = ""
extracted_path = ""  # 必要に応じて設定

# 入力フォルダ選択用のボタンが押された時に呼ばれる関数
def select_input_folder():
    global input_folder
    # フォルダ選択ダイアログを表示してパスを取得
    folder_path = filedialog.askdirectory(title="入力フォルダを選択")
    
    if folder_path:  # ユーザーがフォルダを選んだ場合
        input_folder = folder_path
        print("選択された入力フォルダのパス:", input_folder)
        input_folder_label.config(text="入力フォルダ: " + input_folder)
    else:
        input_folder_label.config(text="入力フォルダが選択されませんでした")

# 保存先フォルダ選択用のボタンが押された時に呼ばれる関数
def select_save_folder():
    global save_folder
    # フォルダ選択ダイアログを表示してパスを取得
    folder_path = filedialog.askdirectory(title="保存先フォルダを選択")
    
    if folder_path:  # ユーザーがフォルダを選んだ場合
        save_folder = folder_path
        print("選択された保存先フォルダのパス:", save_folder)
        save_folder_label.config(text="保存先フォルダ: " + save_folder)
    else:
        save_folder_label.config(text="保存先フォルダが選択されませんでした")

# 実行ボタンが押された時に呼ばれる関数
def execute_action():
    if input_folder and save_folder:  # 入力フォルダと保存先フォルダが選ばれているか確認
        print(f"実行中: {input_folder} から {save_folder} に対して処理を行います。")
        main_GUI.main(input_folder, save_folder)
        result_label.config(text=f"{save_folder} に対して処理が実行されました。")
    else:
        result_label.config(text="入力フォルダまたは保存先フォルダが選択されていません。")

# メインウィンドウを作成
root = tk.Tk()
root.title("フォルダ選択 GUI")  # ウィンドウのタイトル
root.geometry("400x400")  # ウィンドウのサイズ

# 入力フォルダ選択用ボタンを作成
input_folder_button = tk.Button(root, text="入力フォルダを選択", command=select_input_folder)
input_folder_button.pack(pady=10)

# 入力フォルダのパスを表示するラベル
input_folder_label = tk.Label(root, text="入力フォルダがまだ選択されていません")
input_folder_label.pack(pady=10)

# 保存先フォルダ選択用ボタンを作成
save_folder_button = tk.Button(root, text="保存先フォルダを選択", command=select_save_folder)
save_folder_button.pack(pady=10)

# 保存先フォルダのパスを表示するラベル
save_folder_label = tk.Label(root, text="保存先フォルダがまだ選択されていません")
save_folder_label.pack(pady=10)

# 実行ボタンを作成
execute_button = tk.Button(root, text="実行", command=execute_action)
execute_button.pack(pady=20)

# 結果を表示するラベル
result_label = tk.Label(root, text="ここに結果が表示されます")
result_label.pack(pady=10)

# メインループ
root.mainloop()
