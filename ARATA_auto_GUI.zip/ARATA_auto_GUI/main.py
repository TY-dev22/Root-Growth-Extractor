#POC同士の位置合わせを行いながら補正を行う（前　→　後　でbUnwarpJをしている　（元のauto4から変更）
#パディング、切り抜きを縦横でサイズを調整できるようにする予定
from modules import bUnwarpJ, growth_death, image_prepare, iso, line_noize, mkdirs   
import glob
import cv2
import os

def save(imgs, path, names):
    for i,j in zip(imgs, names):
        cv2.imwrite(fr"{path}\{j}", i)

def main(pxcel_v, pxcel_h, Fiji_path):
    names = list(i.split("\\")[-1] for i in glob.glob(fr"extract\*"))
    mkdirs.main()
    #二値化
    imgs = image_prepare.main(fr"extract")
    #パディング
    save(imgs, fr"output\total", names)
    temp_path = fr"tmp\tmp.png"
    path = glob.glob(fr"output\total\*")
    for i in range(len(path)-1):
        POC_img = iso.main(imgs[i], imgs[i+1], pxcel_v, pxcel_h)
        cv2.imwrite(fr"tmp\POC.png", POC_img)
        bUn_img = bUnwarpJ.bUnwarpJ(Fiji_path, fr"tmp\POC.png", path[i+1], temp_path)
        growth_img, death_img = growth_death.growth_death(bUn_img, imgs[i+1])
        total, growth, death =  line_noize.main(bUn_img, imgs[i+1], growth_img, death_img, 2)
        cv2.imwrite(fr"output\total\{names[i+1]}",  total)
        cv2.imwrite(fr"output\growth\{names[i+1]}", growth)
        cv2.imwrite(fr"output\death\{names[i+1]}",  death)

if __name__ == "__main__":
    exracted_imgs_path = fr"C:\Users\rg-biosys\.pyenv\ARATA-main\ana_output"
    pxcel_v = 200
    pxcel_h = 100
    Fiji_path = fr"C:\Users\rg-biosys\Documents\Fiji.app"
    #Javaヒープメモリを8GBに設定(実行環境によっては不要)
    #os.environ["JAVA_TOOL_OPTIONS"] = "-Xmx8g" 
    
    #メイン関数
    main(pxcel_v, pxcel_h, Fiji_path)

    """#位置ズレ考慮のための切り抜き（オプション機能）
    import cv2
    path = glob.glob(fr"{base_dir}\*")
    for i in path:
        crip_imgs = fr"{i}\crip_imgs"
        mkdirs.mkdir(crip_imgs)
        POC_imgs = glob.glob(fr"{i}\POC\*")
        for j in POC_imgs:
            name = j.split("\\")[-1]
            img = cv2.imread(j, 0)
            iso.crip(img, crip_imgs, pxcel_v, pxcel_h , name)"""
    