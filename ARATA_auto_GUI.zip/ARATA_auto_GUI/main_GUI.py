#POC同士の位置合わせを行いながら補正を行う（前　→　後　でbUnwarpJをしている　（元のauto4から変更）
#パディング、切り抜きを縦横でサイズを調整できるようにする予定
from modules import bUnwarpJ, growth_death, image_prepare, iso, line_noize, mkdirs   
import glob
import cv2
import os

def save(imgs, path, names):
    for i,j in zip(imgs, names):
        cv2.imwrite(fr"{path}\{j}", i)

def task(exracted_path, save_path, pxcel_v, pxcel_h, Fiji_path):
    names = list(i.split("\\")[-1] for i in glob.glob(fr"{exracted_path}\*"))
    mkdirs.main(save_path)
    #二値化
    imgs = image_prepare.main(fr"{exracted_path}")
    #パディング
    save(imgs, fr"{save_path}\output\total", names)
    temp_path = fr"{save_path}\tmp\tmp.png"
    path = glob.glob(fr"output\total\*")
    for i in range(len(path)-1):
        POC_img = iso.main(imgs[i], imgs[i+1], pxcel_v, pxcel_h)
        cv2.imwrite(fr"{save_path}\tmp\POC.png", POC_img)
        bUn_img = bUnwarpJ.bUnwarpJ(Fiji_path, fr"{save_path}\tmp\POC.png", path[i+1], temp_path)
        growth_img, death_img = growth_death.growth_death(bUn_img, imgs[i+1])
        total, growth, death =  line_noize.main(bUn_img, imgs[i+1], growth_img, death_img, 2)
        cv2.imwrite(fr"{save_path}\output\total\{names[i+1]}",  total)
        cv2.imwrite(fr"{save_path}\output\growth\{names[i+1]}", growth)
        cv2.imwrite(fr"{save_path}\output\death\{names[i+1]}",  death)

def main(exracted_path, save_path):
    pxcel_v = 200
    pxcel_h = 100
    Fiji_path = fr"C:\Fiji.app" #要変更：Fiji.appのパスを指定
    #Javaヒープメモリを8GBに設定(実行環境によっては不要)
    #os.environ["JAVA_TOOL_OPTIONS"] = "-Xmx8g" 
    
    #メイン関数
    task(exracted_path, save_path, pxcel_v, pxcel_h, Fiji_path)

    