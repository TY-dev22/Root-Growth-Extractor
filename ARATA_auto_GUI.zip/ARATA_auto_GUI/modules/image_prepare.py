import glob
import cv2
import shutil

def white(img):
    img = cv2.imread(img, 0)
    ret, img_thresh = cv2.threshold(img, 50, 255, cv2.THRESH_BINARY)
    if img_thresh.shape != (7021, 5100):
        img_thresh = cv2.resize(img_thresh, (5100, 7021))
    return img_thresh
            
def main(extract_path):
    extract = glob.glob(fr"{extract_path}\*")
    imgs = list(white(i) for i in extract)
    return imgs
